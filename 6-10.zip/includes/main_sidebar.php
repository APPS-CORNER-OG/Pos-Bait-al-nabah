<style>
  .sidebar-menu
  {
    background-color: #000000;
  }
</style>
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">

      </div>
      <!-- search form -->
	  <!--
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
          <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
	  -->
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <?php 
      if($_SESSION['adminType']=='admin'){
        ?>
      <ul class="sidebar-menu" data-widget="tree">
		<li><a href="index.php"><i class="fa fa-dashboard"></i> <span>হোম</span></a></li>
		<li><a href="sales-add.php"><i class="fa fa-cart-plus"></i> বিক্রয়</a></li> 
			<li><a href="sales-addnp.php"><i class="fa fa-cart-plus"></i> প্রিন্ট ছাড়া বিক্রয়</a></li> 
        <li class="treeview">
          <a href="#">
            <i class="fa fa-cubes"></i>
            <span>Product</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
			<li><a href="product-add.php"><i class="fa fa-plus-circle"></i> নতুন প্রোডাক্ট যুক্ত করুন</a></li>
            <li><a href="product-list.php"><i class="fa fa-list"></i> প্রোডাক্ট লিস্ট</a></li>
            <li><a href="product-category.php"><i class="fa fa-newspaper-o"></i> প্রোডাক্ট ক্যাটাগরি</a></li>
            <li><a href="product-category-add.php"><i class="fa fa-plus-circle"></i> ক্যাটাগরি যুক্ত করুন</a></li>
			       <li><a href="product-sub-category-add.php"><i class="fa fa-plus-circle"></i>সাব ক্যাটাগরি যুক্ত করুন</a></li>
          </ul>
        </li>
    <li><a href="barcode.php"><i class="fa fa-barcode"></i> <span>বারকোড প্রিন্ট করুন ২ কলাম</span></a></li>  
     <li><a href="barcode2.php"><i class="fa fa-barcode"></i> <span>বারকোড প্রিন্ট করুন ৩ কলাম</span></a></li>    
		<li><a href="clients.php"><i class="fa fa-users"></i> <span>ক্লায়েন্ট</span></a></li>
    <li><a href="suppliers.php"><i class="fa fa-handshake-o"></i> <span>সাপ্লাইকারী</span></a></li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-money"></i>
            <span>খরচ</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          <li><a href="purchase-rawmaeetrial.php"><i class="fa fa-plus-circle"></i> কাঁচা মাল ক্রয়</a></li> 
          <li><a href="raw-product-list.php"><i class="fa fa-plus-circle"></i> কাঁচা মাল লিস্ট</a></li>    
          <li><a href="barcode_raw.php"><i class="fa fa-plus-circle"></i> কাঁচা মাল বারকোড</a></li>               
            <li><a href="expense-add.php"><i class="fa fa-plus-circle"></i> খরচ যোগ করুন</a></li>            
            <li><a href="expense.php"><i class="fa fa-money"></i> খরচের লিস্ট</a></li>
            <li><a href="wastage.php"><i class="fa fa-money"></i> পণ্য নষ্টের দাম</a></li>
            <li><a href="expense-category.php"><i class="fa fa-list"></i> খরচের ক্যাটাগরি যুক্ত করুন </a></li>
            <li><a href="expense-category-add.php"><i class="fa fa-plus-circle"></i>  নতুন খরচের ক্যাটাগরি যুক্ত করুন </a></li>
          </ul>
        </li> 
    <li class="treeview">
          <a href="#">
            <i class="fa fa-newspaper-o"></i>
            <span>রিপোর্ট</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="sales.php"><i class="fa fa-shopping-cart"></i> সব সেল রিপোর্ট</a></li>
            <li><a href="product-sold-list.php"><i class="fa fa-list"></i>বিক্রিত আইটেম</a></li> 
            <li><a href="sales-reporting-list.php"><i class="fa fa-list"></i>
সেল রিপোর্ট</a></li> 		  
            <li><a href="product-current-stock-list.php"><i class="fa fa-cube"></i>কারেন্ট স্টক</a></li>
           <!--   <li><a href="reporting.php"><i class="fa fa-list"></i>আয় এবং ব্যয়</a></li>  -->
            <li><a href="income_expense_date_search.php"><i class="fa fa-list"></i> আয় এবং ব্যয়</a></li>

          </ul>
    </li>    
		<li><a href="staff.php"><i class="fa fa-user-circle-o"></i> <span>স্টাফ</span></a></li>
		<li><a href="settings.php"><i class="fa fa-wrench"></i> <span>সেটিংস</span></a></li>
		<li><a href="profile.php"><i class="fa fa-user"></i> <span>প্রোফাইল</span></a></li>
    <li><a href="db/db_export.php" target="_blank"><i class="fa fa-download"></i> <span>ব্যাকআপ</span></a></li>
      </ul>
      <?php } ?>
      <?php 
       if($_SESSION['adminType']=='sales')
       {
      ?>
      <ul class="sidebar-menu" data-widget="tree">
		<li><a href="index.php"><i class="fa fa-dashboard"></i> <span>হোম</span></a></li>
		<li><a href="sales-add.php"><i class="fa fa-cart-plus"></i> বিক্রয়</a></li> 
			<li><a href="sales-addnp.php"><i class="fa fa-cart-plus"></i> প্রিন্ট ছাড়া বিক্রয়</a></li> 
       
    <li><a href="barcode.php"><i class="fa fa-barcode"></i> <span>বারকোড প্রিন্ট করুন ২ কলাম</span></a></li>  
     <li><a href="barcode2.php"><i class="fa fa-barcode"></i> <span>বারকোড প্রিন্ট করুন ৩ কলাম</span></a></li>    
	
        
   
	
    <li><a href="db/db_export.php" target="_blank"><i class="fa fa-download"></i> <span>ব্যাকআপ</span></a></li>
      </ul>
      <?php } ?>
    </section>
    <!-- /.sidebar -->
  </aside>