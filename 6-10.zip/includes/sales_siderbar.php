<style>
  .sidebar-menu
  {
    background-color: #000000;
  }
</style>
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">

      </div>
      <!-- search form -->
	  <!--
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
          <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
	  -->
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
		<li><a href="index.php"><i class="fa fa-dashboard"></i> <span>হোম</span></a></li>
		<li><a href="sales-add.php"><i class="fa fa-cart-plus"></i> বিক্রয়</a></li> 
			<li><a href="sales-addnp.php"><i class="fa fa-cart-plus"></i> প্রিন্ট ছাড়া বিক্রয়</a></li> 
       
    <li><a href="barcode.php"><i class="fa fa-barcode"></i> <span>বারকোড প্রিন্ট করুন ২ কলাম</span></a></li>  
     <li><a href="barcode2.php"><i class="fa fa-barcode"></i> <span>বারকোড প্রিন্ট করুন ৩ কলাম</span></a></li>    
	
        
   
	
    <li><a href="db/db_export.php" target="_blank"><i class="fa fa-download"></i> <span>ব্যাকআপ</span></a></li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>