<?php 	

// For Localhost
$localhost = "localhost";
$username = "root";
$password = "";
$databaseName = "b";

//For Server
/*
$localhost = "127.0.0.1";
$username = "corporatesolutio";
$password = "SUesfar@4312";
$databaseName = "corporat_pos";
*/

// db connection
$connection = new mysqli($localhost, $username, $password, $databaseName);
// check connection
if($connection->connect_error) {
  die("Connection Failed : " . $connection->connect_error);
} else {
  // echo "Successfully connected";
}

?>